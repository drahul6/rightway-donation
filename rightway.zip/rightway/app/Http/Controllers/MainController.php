<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MainController extends Controller
{
  public function aboutUs() {
    return view('about');
  }

  public function trainers() {
    return view('trainers');
  }

  public function courses() {
    return view('courses');
  }

  public function courseDetails() {
    return view('course-details');
  }

  public function events() {
    return view('events');
  }

  public function pricing() {
    return view('pricing');
  }

  public function contactUs() {
    return view('contact');
  }

}
