<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('about-us', 'MainController@aboutUs')->name('about-us');
Route::get('courses', 'MainController@courses')->name('courses');
Route::get('contact-us', 'MainController@contactUs')->name('contact-us');
Route::get('trainers', 'MainController@trainers')->name('trainers');
Route::get('course/details', 'MainController@courseDetails')->name('course.details');
Route::get('pricing', 'MainController@pricing')->name('pricing');
Route::get('events', 'MainController@events')->name('events');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
